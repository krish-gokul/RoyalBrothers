<?php
$DB = "royalbrother";
$USER 		= "root";
$PASSWORD 	= "";
$HOST 		= "localhost";

$con = mysqli_connect($HOST,$USER,$PASSWORD,$DB) or die(mysqli_connect_error()); 
?>